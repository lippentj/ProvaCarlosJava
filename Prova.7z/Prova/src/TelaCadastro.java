import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaCadastro extends JFrame {
    private JTextField campoNome;
    private JTextField campoLogin;
    private JPasswordField campoSenha;
    private JTextField campoEmail;

    public TelaCadastro() {
        super("Cadastro de Usuário");

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(300, 200);
        setLocationRelativeTo(null);

        JPanel painel = new JPanel();
        painel.setLayout(new BoxLayout(painel, BoxLayout.Y_AXIS));

        campoNome = new JTextField(20);
        campoLogin = new JTextField(20);
        campoSenha = new JPasswordField(20);
        campoEmail = new JTextField(20);

        JButton botaoCadastrar = new JButton("Cadastrar");

        botaoCadastrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = campoNome.getText();
                String login = campoLogin.getText();
                String senha = new String(campoSenha.getPassword());
                String email = campoEmail.getText();

                // Crie uma instância de Login com os valores fornecidos
                Login novoUsuario = new Login(nome, login, senha, email);

                if (ControleUsuario.cadastrarUsuario(novoUsuario)) {
                    JOptionPane.showMessageDialog(null, "Cadastro efetuado com sucesso");
                    dispose(); // Fecha a janela de cadastro após o sucesso
                } else {
                    JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário.");
                }
            }
        });

        painel.add(new JLabel("Nome:"));
        painel.add(campoNome);
        painel.add(new JLabel("Login:"));
        painel.add(campoLogin);
        painel.add(new JLabel("Senha:"));
        painel.add(campoSenha);
        painel.add(new JLabel("Email:"));
        painel.add(campoEmail);
        painel.add(botaoCadastrar);

        add(painel);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new TelaCadastro();
            }
        });
    }
}