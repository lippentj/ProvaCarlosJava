import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControleUsuario {

    public static boolean autenticarUsuario(String login, String senha) {
        String sql = "SELECT id, nome, login, senha, email FROM usuario WHERE login = ? AND senha = ?";

        try (Connection conexao = ConexaoBD.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, login);
            stmt.setString(2, senha);

            ResultSet resultado = stmt.executeQuery();

            if (resultado.next()) {
                System.out.println("Acesso Autorizado");
                return true;
            } else {
                System.out.println("Acesso Negado");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean cadastrarUsuario(Login novoUsuario) {
        String sql = "INSERT INTO usuario (nome, login, senha, email) VALUES (?, ?, ?, ?)";

        try (Connection conexao = ConexaoBD.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, Login.getNome());
            stmt.setString(2, Login.getLogin());
            stmt.setString(3, Login.getSenha());
            stmt.setString(4, Login.getEmail());

            int linhasAfetadas = stmt.executeUpdate();

            if (linhasAfetadas > 0) {
                System.out.println("Cadastro efetuado com sucesso");
                return true;
            } else {
                System.out.println("Erro ao cadastrar usuário");
                return false;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}