import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    public static Connection getConex() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Conectado com o banco de dados!");
            return DriverManager.getConnection("jdbc:mysql://localhost/prova", "root", "");
        } catch (ClassNotFoundException e) {
            throw new SQLException(e.getMessage());

        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Conexao();
            }
        });
    }
}
